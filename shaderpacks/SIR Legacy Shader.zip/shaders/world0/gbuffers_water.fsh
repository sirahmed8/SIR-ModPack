#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define GBUFFER_WATER
#define WATER_F

#include "/common/water_blocks_fragment.glsl"
