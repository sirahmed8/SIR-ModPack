#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define DEFERRED_SHADER

#include "/common/deferred_vertex.glsl"
