#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define COMPOSITE2_SHADER
#define NO_SHADOWS

#include "/common/composite2_fragment.glsl"
