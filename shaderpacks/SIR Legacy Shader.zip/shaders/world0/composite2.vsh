#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define COMPOSITE2_SHADER

#include "/common/composite2_vertex.glsl"
