#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define GBUFFER_BASIC
#define NO_SHADOWS
#define SHADER_LINE

#include "/common/basic_blocks_vertex.glsl"
