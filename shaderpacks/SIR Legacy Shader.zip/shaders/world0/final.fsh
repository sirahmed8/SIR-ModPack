#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define FINAL_SHADER
#define NO_SHADOWS

#include "/common/final_fragment.glsl"
