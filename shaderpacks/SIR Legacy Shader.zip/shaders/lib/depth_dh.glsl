/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

float ld_dh(float depth) {
    return (2.0 * dhNearPlane) / (dhFarPlane + dhNearPlane - depth * (dhFarPlane - dhNearPlane));
}
