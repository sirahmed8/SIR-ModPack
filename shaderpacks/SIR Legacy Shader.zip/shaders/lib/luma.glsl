/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

float luma(vec3 color) {
    return dot(color, vec3(0.2126, 0.7152, 0.0722));
}

float colorAverage(vec3 color) {
    return (color.r + color.g + color.b) * 0.3333333333;
}
