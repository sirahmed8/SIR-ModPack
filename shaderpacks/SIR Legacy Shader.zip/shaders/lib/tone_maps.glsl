/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

// vec3 custom_sigmoid(vec3 color) {
//     color = 1.4 * color;
//     color = color / pow(pow(color, vec3(3.0)) + 1.0, vec3(0.3333333333333));

//     return pow(color, vec3(1.15));
// }

vec3 custom_sigmoid(vec3 color) {
    color = 1.4 * color;
    color = color / pow(pow(color, vec3(2.5)) + vec3(1.0), vec3(0.4));

    return pow(color, vec3(1.15));
}