/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

float ld(float depth) {
    return (2.0 * near) / (far + near - depth * (far - near));
}
