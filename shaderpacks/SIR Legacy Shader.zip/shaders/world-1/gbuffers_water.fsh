#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define NETHER
#define GBUFFER_WATER
#define WATER_F
#define NO_SHADOWS

#include "/common/water_blocks_fragment.glsl"
