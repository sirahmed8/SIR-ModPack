#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define NETHER
#define GBUFFER_HAND_WATER
#define NO_SHADOWS
#define SPECIAL_TRANS

#include "/common/solid_blocks_fragment.glsl"