#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define DH_BLOCK
#define NETHER

#include "/common/solid_dh_blocks_vertex.glsl"
