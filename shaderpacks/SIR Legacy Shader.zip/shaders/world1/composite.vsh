#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define THE_END
#define COMPOSITE_SHADER

#include "/common/composite_vertex.glsl"
