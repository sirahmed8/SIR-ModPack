#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define DH_WATER
#define THE_END

#include "/common/solid_dh_water_fragment.glsl"
