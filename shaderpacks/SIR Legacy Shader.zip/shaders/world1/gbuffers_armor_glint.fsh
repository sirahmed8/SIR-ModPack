#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define THE_END
#define GBUFFER_ARMOR_GLINT
#define SHADER_BASIC

#include "/common/glint_blocks_fragment.glsl"
