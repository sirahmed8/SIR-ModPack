#version 120
#extension GL_ARB_shader_texture_lod : enable
/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */

#define THE_END
#define NO_SHADOWS
#define GBUFFER_DAMAGE

#include "/common/damage_fragment.glsl"