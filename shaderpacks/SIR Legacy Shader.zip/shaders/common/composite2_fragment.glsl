#include "/lib/config.glsl"

const bool colortex0Clear = false;
const bool colortex1Clear = false;
const bool colortex2Clear = false;
const bool colortex3Clear = false;
const bool gaux1Clear = false;
const bool gaux2Clear = false;
const bool gaux3Clear = false;
const bool gaux4Clear = false;

/* SIR Legacy Shader Engine v1.0.0 — Proprietary & Confidential */
        gl_FragData[0] = blockColor;  // colortex1
        gl_FragData[1] = blockColor;  // To TAA averages
    #else
        blockColor = clamp(blockColor, vec4(0.0), vec4(vec3(50.0), 1.0));
        /* DRAWBUFFERS:1 */
        gl_FragData[0] = blockColor;  // colortex1
    #endif
}
